// db.js - Improved data access
class Database {
    constructor() {
      this.data = JSON.parse(localStorage.getItem('animeDB')) || { users: [], anime: [] };
    }
  
    getAllAnime() {
      return this.data.anime || [];
    }
  
    getAnimeByGenre(genre) {
      return this.data.anime.filter(anime => 
        anime.genera && anime.genera.includes(genre)
      );
    }
  
    searchAnime(query) {
      query = query.toLowerCase();
      return this.data.anime.filter(anime => 
        anime.name.toLowerCase().includes(query)
      );
    }
  
    getCurrentUser() {
      const email = localStorage.getItem('currentUserEmail');
      if (!email) return null;
      return this.data.users.find(user => user.email === email);
    }
  
    getUserWatchlist() {
      const user = this.getCurrentUser();
      if (!user || !user.watchlist) return [];
      return user.watchlist;
    }
  
    // Add more methods as needed
  }
  
  const db = new Database();