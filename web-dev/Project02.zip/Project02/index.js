// Global variables to store data
let animeData = [];
let userData = null;
let isLoggedIn = false;
let notifications = [];

// DOM Elements
const searchInput = document.getElementById('searchInput');
const searchResults = document.getElementById('searchResults');
const notificationBtn = document.getElementById('notificationBtn');
const notificationPanel = document.getElementById('notificationPanel');
const notificationList = document.getElementById('notificationList');
const notificationCount = document.querySelector('.notification-count');
const userBtn = document.getElementById('userBtn');
const loginBtn = document.getElementById('loginBtn');
const heroSlider = document.getElementById('heroSlider');
const trendingGrid = document.getElementById('trendingGrid');
const actionGrid = document.getElementById('actionGrid');
const adventureGrid = document.getElementById('adventureGrid');
const comedyGrid = document.getElementById('comedyGrid');
const loadMoreButtons = document.querySelectorAll('.load-more');

// Pagination settings for each section
const paginationState = {
    trending: { page: 1, limit: 10, total: 0 },
    action: { page: 1, limit: 10, total: 0 },
    adventure: { page: 1, limit: 10, total: 0 },
    comedy: { page: 1, limit: 10, total: 0 }
};

// Initialize application
document.addEventListener('DOMContentLoaded', () => {
    initApp();
});

async function initApp() {
    await fetchData();
    checkUserAuthentication();
    setupEventListeners();
    initializeHeroSlider();
    loadAnimeSections();
}

// Fetch data from db.json
async function fetchData() {
    try {
        const response = await fetch('./db.json');
        if (!response.ok) {
            throw new Error('Failed to fetch data');
        }
        const data = await response.json();
        animeData = data.anime || [];
        
        // Count the total number of anime for each category for pagination
        paginationState.trending.total = animeData.length;
        paginationState.action.total = animeData.filter(anime => anime.genera.includes('action')).length;
        paginationState.adventure.total = animeData.filter(anime => anime.genera.includes('adventure')).length;
        paginationState.comedy.total = animeData.filter(anime => anime.genera.includes('comedy')).length;
        
        console.log('Data loaded successfully:', animeData.length, 'anime found');
    } catch (error) {
        console.error('Error fetching data:', error);
        // Fallback to sample data for development
        loadSampleData();
    }
}

// Load sample data if fetch fails (for development)
function loadSampleData() {
    console.warn('Using sample data due to fetch error');
    animeData = [
        {
            id: 1,
            name: "Demon Slayer",
            description: "A young boy named Tanjiro Kamado becomes a demon slayer after his family is slaughtered and his sister Nezuko is turned into a demon.",
            genera: ["action", "adventure", "fantasy"],
            rating: 4.8,
            image: "./assets/anime/demon_slayer.jpg",
            episodes: [
                { number: 1, title: "Cruelty", src: "./assets/videos/demo.mp4" },
                { number: 2, title: "Trainer Sakonji Urokodaki", src: "./assets/videos/demo.mp4" },
                { number: 3, title: "Sabito and Makomo", src: "./assets/videos/demo.mp4" }
            ]
        },
        {
            id: 2,
            name: "Attack on Titan",
            description: "In a world where humanity lives within cities surrounded by enormous walls that protect them from giant man-eating humanoids, a young boy vows to destroy them all.",
            genera: ["action", "drama", "fantasy"],
            rating: 4.9,
            image: "./assets/anime/attack_on_titan.jpg",
            episodes: [
                { number: 1, title: "To You, 2000 Years Later", src: "./assets/videos/demo.mp4" },
                { number: 2, title: "That Day", src: "./assets/videos/demo.mp4" },
                { number: 3, title: "A Dim Light Amid Despair", src: "./assets/videos/demo.mp4" }
            ]
        },
        {
            id: 3,
            name: "My Hero Academia",
            description: "A superhero-loving boy without any powers enrolls in a prestigious hero academy and learns what it really means to be a hero.",
            genera: ["action", "comedy", "adventure"],
            rating: 4.7,
            image: "./assets/anime/my_hero_academia.jpg",
            episodes: [
                { number: 1, title: "Izuku Midoriya: Origin", src: "./assets/videos/demo.mp4" },
                { number: 2, title: "What It Takes to Be a Hero", src: "./assets/videos/demo.mp4" },
                { number: 3, title: "Roaring Muscles", src: "./assets/videos/demo.mp4" }
            ]
        },
        {
            id: 4,
            name: "One Piece",
            description: "Follows the adventures of Monkey D. Luffy and his pirate crew in order to find the greatest treasure ever left by the legendary Pirate, Gold Roger.",
            genera: ["action", "adventure", "comedy"],
            rating: 4.9,
            image: "./assets/anime/one_piece.jpg",
            episodes: [
                { number: 1, title: "I'm Luffy! The Man Who's Gonna Be King of the Pirates!", src: "./assets/videos/demo.mp4" },
                { number: 2, title: "Enter the Great Swordsman! Pirate Hunter Roronoa Zoro!", src: "./assets/videos/demo.mp4" },
                { number: 3, title: "Morgan versus Luffy! Who's the Mysterious Pretty Girl?", src: "./assets/videos/demo.mp4" }
            ]
        },
        {
            id: 5,
            name: "Jujutsu Kaisen",
            description: "A boy swallows a cursed talisman - the finger of a demon - and becomes cursed himself. He enters a shaman school to be able to locate the demon's other body parts and thus exorcise himself.",
            genera: ["action", "fantasy", "supernatural"],
            rating: 4.8,
            image: "./assets/anime/jujutsu_kaisen.jpg",
            episodes: [
                { number: 1, title: "Ryomen Sukuna", src: "./assets/videos/demo.mp4" },
                { number: 2, title: "For Myself", src: "./assets/videos/demo.mp4" },
                { number: 3, title: "Girl of Steel", src: "./assets/videos/demo.mp4" }
            ]
        },
        {
            id: 6,
            name: "Spy x Family",
            description: "A spy on an undercover mission gets married and adopts a child as part of his cover. His wife and daughter have secrets of their own, and neither knows the other's true identity.",
            genera: ["comedy", "action", "slice of life"],
            rating: 4.7,
            image: "./assets/anime/spy_family.jpg",
            episodes: [
                { number: 1, title: "Operation Strix", src: "./assets/videos/demo.mp4" },
                { number: 2, title: "Secure a Wife", src: "./assets/videos/demo.mp4" },
                { number: 3, title: "Prepare for the Interview", src: "./assets/videos/demo.mp4" }
            ]
        },
        {
            id: 7,
            name: "Violet Evergarden",
            description: "A former soldier adjusts to civilian life by working as an Auto Memory Doll, writing letters for people who cannot write.",
            genera: ["drama", "fantasy", "slice of life"],
            rating: 4.8,
            image: "./assets/anime/violet_evergarden.jpg",
            episodes: [
                { number: 1, title: "I Love You and Auto Memory Dolls", src: "./assets/videos/demo.mp4" },
                { number: 2, title: "Never Coming Back", src: "./assets/videos/demo.mp4" },
                { number: 3, title: "May You Be an Exemplary Automemory Doll", src: "./assets/videos/demo.mp4" }
            ]
        },
        {
            id: 8,
            name: "Chainsaw Man",
            description: "A teenager is forced to hunt down devils with his devil-dog pet in order to pay off his father's debt.",
            genera: ["action", "horror", "supernatural"],
            rating: 4.6,
            image: "./assets/anime/chainsaw_man.jpg",
            episodes: [
                { number: 1, title: "Dog & Chainsaw", src: "./assets/videos/demo.mp4" },
                { number: 2, title: "Arrival in Tokyo", src: "./assets/videos/demo.mp4" },
                { number: 3, title: "Meowy's Whereabouts", src: "./assets/videos/demo.mp4" }
            ]
        },
        {
            id: 9,
            name: "Fullmetal Alchemist: Brotherhood",
            description: "Two brothers search for the Philosopher's Stone to restore their bodies after a failed alchemical experiment.",
            genera: ["action", "adventure", "fantasy"],
            rating: 4.9,
            image: "./assets/anime/fullmetal_alchemist.jpg",
            episodes: [
                { number: 1, title: "Fullmetal Alchemist", src: "./assets/videos/demo.mp4" },
                { number: 2, title: "The First Day", src: "./assets/videos/demo.mp4" },
                { number: 3, title: "City of Heresy", src: "./assets/videos/demo.mp4" }
            ]
        },
        {
            id: 10,
            name: "Death Note",
            description: "A high school student discovers a supernatural notebook that grants him the ability to kill anyone by writing their name while picturing their face.",
            genera: ["mystery", "psychological", "supernatural"],
            rating: 4.7,
            image: "./assets/anime/death_note.jpg",
            episodes: [
                { number: 1, title: "Rebirth", src: "./assets/videos/demo.mp4" },
                { number: 2, title: "Confrontation", src: "./assets/videos/demo.mp4" },
                { number: 3, title: "Dealings", src: "./assets/videos/demo.mp4" }
            ]
        },
        {
            id: 11,
            name: "Komi Can't Communicate",
            description: "A girl with social anxiety disorder wants to make 100 friends in high school with the help of her first friend.",
            genera: ["comedy", "slice of life", "romance"],
            rating: 4.5,
            image: "./assets/anime/komi_san.jpg",
            episodes: [
                { number: 1, title: "It's Just a Normal Person", src: "./assets/videos/demo.mp4" },
                { number: 2, title: "The Reason Behind The Blackboard", src: "./assets/videos/demo.mp4" },
                { number: 3, title: "I Want to Talk", src: "./assets/videos/demo.mp4" }
            ]
        },
        {
            id: 12,
            name: "Your Lie in April",
            description: "A piano prodigy who lost his ability to play after his mother's death meets a violinist who helps him return to the music world.",
            genera: ["drama", "romance", "music"],
            rating: 4.8,
            image: "./assets/anime/your_lie_in_april.jpg",
            episodes: [
                { number: 1, title: "Monotone/Colorful", src: "./assets/videos/demo.mp4" },
                { number: 2, title: "Friend A", src: "./assets/videos/demo.mp4" },
                { number: 3, title: "Inside Spring", src: "./assets/videos/demo.mp4" }
            ]
        }
    ];
    
    // Set pagination totals
    paginationState.trending.total = animeData.length;
    paginationState.action.total = animeData.filter(anime => anime.genera.includes('action')).length;
    paginationState.adventure.total = animeData.filter(anime => anime.genera.includes('adventure')).length;
    paginationState.comedy.total = animeData.filter(anime => anime.genera.includes('comedy')).length;
}

// Check if user is logged in
function checkUserAuthentication() {
    const loggedInUser = localStorage.getItem('currentUser');
    if (loggedInUser) {
        userData = JSON.parse(loggedInUser);
        isLoggedIn = true;
        
        // Update UI based on login status
        userBtn.style.display = 'flex';
        loginBtn.style.display = 'none';
        
        // Check for notifications
        fetchNotifications();
    } else {
        isLoggedIn = false;
        
        // Update UI based on login status
        userBtn.style.display = 'none';
        loginBtn.style.display = 'flex';
        
        // Hide notification count
        notificationCount.style.display = 'none';
    }
}

// Setup event listeners
function setupEventListeners() {
    // Search functionality
    searchInput.addEventListener('input', handleSearch);
    searchInput.addEventListener('focus', () => {
        if (searchInput.value.trim().length >= 2) {
            searchResults.classList.add('active');
        }
    });
    
    // Notification panel toggle
    notificationBtn.addEventListener('click', toggleNotificationPanel);
    
    // User button click to go to profile page
    userBtn.addEventListener('click', () => {
        window.location.href = './user.html';
    });
    
    // Login button click to go to auth page
    loginBtn.addEventListener('click', () => {
        window.location.href = './auth.html';
    });
    
    // Load more buttons
    loadMoreButtons.forEach(button => {
        button.addEventListener('click', () => {
            const section = button.getAttribute('data-section');
            loadMoreAnime(section);
        });
    });
    
    // Close notification panel when clicking outside
    document.addEventListener('click', (e) => {
        if (!notificationBtn.contains(e.target) && !notificationPanel.contains(e.target)) {
            notificationPanel.classList.remove('active');
        }
    });
    
    // Close search results when clicking outside
    document.addEventListener('click', (e) => {
        if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
            searchResults.classList.remove('active');
        }
    });
}

// Initialize Hero Slider
function initializeHeroSlider() {
    // Clear existing slider content
    heroSlider.innerHTML = '';
    
    // Get top 10 anime for the slider based on rating
    const topAnime = [...animeData]
        .sort((a, b) => b.rating - a.rating)
        .slice(0, 10);
    
    // Create slider slides
    topAnime.forEach(anime => {
        const slide = document.createElement('div');
        slide.className = 'swiper-slide';
        
        slide.innerHTML = `
            <div class="slide-background" style="background-image: url('${anime.image}')"></div>
            <div class="slide-overlay">
                <div class="slide-content">
                    <h2>${anime.name}</h2>
                    <div class="rating">
                        <div class="stars">
                            ${getStarRating(anime.rating)}
                        </div>
                        <span>${anime.rating.toFixed(1)}/5.0</span>
                    </div>
                    <p>${anime.description.length > 150 ? anime.description.substring(0, 150) + '...' : anime.description}</p>
                    <a href="anime_info.html?id=${anime.id}" class="btn">Watch Now</a>
                </div>
            </div>
        `;
        
        heroSlider.appendChild(slide);
    });
    
    // Initialize Swiper
    const swiper = new Swiper('.swiper', {
        loop: true,
        autoplay: {
            delay: 10000,
            disableOnInteraction: false,
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        effect: 'fade',
        fadeEffect: {
            crossFade: true
        },
        on: {
            slideChangeTransitionStart: function() {
                // Add animation to slide content
                document.querySelector('.swiper-slide-active .slide-content').style.animation = 'none';
                setTimeout(() => {
                    document.querySelector('.swiper-slide-active .slide-content').style.animation = 'fadeIn 1s ease';
                }, 10);
            }
        }
    });
}

// Load anime sections
function loadAnimeSections() {
    // Clear all grids first
    trendingGrid.innerHTML = '';
    actionGrid.innerHTML = '';
    adventureGrid.innerHTML = '';
    comedyGrid.innerHTML = '';
    
    loadTrendingAnime();
    loadActionAnime();
    loadAdventureAnime();
    loadComedyAnime();
    
    // Check if we should hide any "Load More" buttons
    checkLoadMoreButtonsVisibility();
}

// Load trending anime (based on rating)
function loadTrendingAnime() {
    const { page, limit } = paginationState.trending;
    const startIndex = 0;
    const endIndex = page * limit;
    
    // Get top rated anime
    const trending = [...animeData]
        .sort((a, b) => b.rating - a.rating)
        .slice(startIndex, endIndex);
    
    // Render anime cards
    renderAnimeCards(trending, trendingGrid);
}

// Load action anime
function loadActionAnime() {
    const { page, limit } = paginationState.action;
    const startIndex = 0;
    const endIndex = page * limit;
    
    // Get action anime
    const actionAnime = animeData
        .filter(anime => anime.genera.includes('action'))
        .slice(startIndex, endIndex);
    
    // Render anime cards
    renderAnimeCards(actionAnime, actionGrid);
}

// Load adventure anime
function loadAdventureAnime() {
    const { page, limit } = paginationState.adventure;
    const startIndex = 0;
    const endIndex = page * limit;
    
    // Get adventure anime
    const adventureAnime = animeData
        .filter(anime => anime.genera.includes('adventure'))
        .slice(startIndex, endIndex);
    
    // Render anime cards
    renderAnimeCards(adventureAnime, adventureGrid);
}

// Load comedy anime
function loadComedyAnime() {
    const { page, limit } = paginationState.comedy;
    const startIndex = 0;
    const endIndex = page * limit;
    
    // Get comedy anime
    const comedyAnime = animeData
        .filter(anime => anime.genera.includes('comedy'))
        .slice(startIndex, endIndex);
    
    // Render anime cards
    renderAnimeCards(comedyAnime, comedyGrid);
}

// Render anime cards with animation
function renderAnimeCards(animeList, container) {
    if (animeList.length === 0) {
        container.innerHTML = '<p class="no-anime">No anime found in this category</p>';
        return;
    }
    
    animeList.forEach((anime, index) => {
        const card = document.createElement('div');
        card.className = 'anime-card';
        
        // Add animation delay based on index
        card.style.animation = `fadeInUp 0.5s ease forwards ${index * 0.05}s`;
        card.style.opacity = '0';
        
        card.innerHTML = `
            <img src="${anime.image}" alt="${anime.name}">
            <div class="anime-card-overlay">
                <h3>${anime.name}</h3>
                <div class="rating">
                    <i class="fas fa-star"></i>
                    <span>${anime.rating.toFixed(1)}</span>
                </div>
            </div>
        `;
        
        // Add click event to redirect to anime info page
        card.addEventListener('click', () => {
            window.location.href = `anime_info.html?id=${anime.id}`;
        });
        
        container.appendChild(card);
    });
    
    // Add fadeInUp animation to CSS
    if (!document.querySelector('#animationStyles')) {
        const styleSheet = document.createElement('style');
        styleSheet.id = 'animationStyles';
        styleSheet.innerHTML = `
            @keyframes fadeInUp {
                from {
                    opacity: 0;
                    transform: translateY(20px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
        `;
        document.head.appendChild(styleSheet);
    }
}

// Load more anime for a specific section
function loadMoreAnime(section) {
    // Increment page
    paginationState[section].page += 1;
    
    // Clear container
    const container = document.getElementById(`${section}Grid`);
    container.innerHTML = '';
    
    // Load anime based on section
    switch(section) {
        case 'trending':
            loadTrendingAnime();
            break;
        case 'action':
            loadActionAnime();
            break;
        case 'adventure':
            loadAdventureAnime();
            break;
        case 'comedy':
            loadComedyAnime();
            break;
    }
    
    // Check if we should hide the load more button
    checkLoadMoreButtonsVisibility();
}

// Check if load more buttons should be visible
function checkLoadMoreButtonsVisibility() {
    loadMoreButtons.forEach(button => {
        const section = button.getAttribute('data-section');
        const { page, limit, total } = paginationState[section];
        
        // Hide button if we've loaded all anime or reached 50 items
        if (page * limit >= total || page * limit >= 50) {
            button.style.display = 'none';
        } else {
            button.style.display = 'block';
        }
    });
}

// Handle search functionality
function handleSearch() {
    const query = searchInput.value.trim().toLowerCase();
    
    if (query.length < 2) {
        searchResults.classList.remove('active');
        return;
    }
    
    // Filter anime by name
    const filteredAnime = animeData.filter(anime => 
        anime.name.toLowerCase().includes(query)
    ).slice(0, 5); // Show max 5 results
    
    // Show or hide search results
    if (filteredAnime.length > 0) {
        searchResults.classList.add('active');
        renderSearchResults(filteredAnime);
    } else {
        searchResults.classList.remove('active');
    }
}

// Render search results
function renderSearchResults(results) {
    searchResults.innerHTML = '';
    
    results.forEach(anime => {
        const resultItem = document.createElement('div');
        resultItem.className = 'search-result-item';
        resultItem.innerHTML = `
            <img src="${anime.image}" alt="${anime.name}">
            <div class="result-info">
                <h4>${anime.name}</h4>
                <p>${anime.rating.toFixed(1)} <i class="fas fa-star"></i></p>
            </div>
        `;
        
        // Add click event to redirect to anime info page
        resultItem.addEventListener('click', () => {
            window.location.href = `anime_info.html?id=${anime.id}`;
        });
        
        searchResults.appendChild(resultItem);
    });
}

// Toggle notification panel
function toggleNotificationPanel() {
    notificationPanel.classList.toggle('active');
    
    // Mark notifications as read when panel is opened
    if (notificationPanel.classList.contains('active') && notifications.length > 0) {
        // In a real application, you would update the server here
        // For this demo, we'll just update the UI
        notificationCount.textContent = '0';
        notificationCount.style.display = 'none';
    }
}

// Fetch notifications
function fetchNotifications() {
    if (!isLoggedIn || !userData) return;
    
    // Get user watchlist
    const watchlist = userData.watchlist || [];
    
    // Get new anime in user's watchlist genres
    let userGenres = new Set();
    
    // Collect user's favorite genres based on watchlist
    watchlist.forEach(animeId => {
        const anime = animeData.find(a => a.id === animeId);
        if (anime) {
            anime.genera.forEach(g => userGenres.add(g));
        }
    });
    
    // Find new anime in user's favorite genres
    // For this example, we'll consider the top 5 anime as "new"
    const newAnime = animeData
        .filter(anime => {
            // Check if any genre matches user's preferences
            return anime.genera.some(g => userGenres.has(g)) && !watchlist.includes(anime.id);
        })
        .sort((a, b) => b.rating - a.rating)
        .slice(0, 5);
    
    // Create notifications
    notifications = newAnime.map(anime => ({
        id: anime.id,
        title: `New anime: ${anime.name}`,
        message: `A new ${anime.genera.join(', ')} anime that might interest you!`,
        time: 'Just added'
    }));
    
    // Update UI
    updateNotifications();
}

// Update notifications in UI
function updateNotifications() {
    // Update notification count
    notificationCount.textContent = notifications.length;
    notificationCount.style.display = notifications.length > 0 ? 'flex' : 'none';
    
    // Update notification list
    if (notifications.length > 0) {
        notificationList.innerHTML = '';
        
        notifications.forEach(notification => {
            const notificationItem = document.createElement('div');
            notificationItem.className = 'notification-item';
            notificationItem.innerHTML = `
                <div class="notification-title">${notification.title}</div>
                <div class="notification-message">${notification.message}</div>
                <div class="notification-time">${notification.time}</div>
            `;
            
            // Add click event to redirect to anime info page
            notificationItem.addEventListener('click', () => {
                window.location.href = `anime_info.html?id=${notification.id}`;
                
                // Close notification panel
                notificationPanel.classList.remove('active');
            });
            
            notificationList.appendChild(notificationItem);
        });
    } else {
        notificationList.innerHTML = '<p class="no-notifications">No new notifications</p>';
    }
}

// Helper function to generate star rating HTML
function getStarRating(rating) {
    const fullStars = Math.floor(rating);
    const halfStar = rating % 1 >= 0.5;
    const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);
    
    let stars = '';
    
    // Full stars
    for (let i = 0; i < fullStars; i++) {
        stars += '<i class="fas fa-star"></i>';
    }
    
    // Half star
    if (halfStar) {
        stars += '<i class="fas fa-star-half-alt"></i>';
    }
    
    // Empty stars
    for (let i = 0; i < emptyStars; i++) {
        stars += '<i class="far fa-star"></i>';
    }
    
    return stars;
}

// Mock function to simulate adding anime to watchlist
// This would be replaced with actual API calls in a real application
function addToWatchlist(animeId) {
    if (!isLoggedIn) {
        alert('Please log in to add anime to your watchlist');
        window.location.href = './auth.html';
        return;
    }
    
    // Update local user data
    if (!userData.watchlist.includes(animeId)) {
        userData.watchlist.push(animeId);
        localStorage.setItem('currentUser', JSON.stringify(userData));
        
        // Show success message
        const toast = document.createElement('div');
        toast.className = 'toast';
        toast.innerHTML = 'Anime added to watchlist!';
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.classList.add('show');
        }, 100);
        
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => {
                document.body.removeChild(toast);
            }, 300);
        }, 3000);
        
        // In a real application, you would update the server here
    }
}

// Add a little bit of CSS animation for toast notifications
const toastStyles = document.createElement('style');
toastStyles.innerHTML = `
    .toast {
        position: fixed;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%) translateY(100px);
        background-color: var(--primary-color);
        color: var(--text-dark);
        padding: 12px 24px;
        border-radius: 30px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        z-index: 2000;
        opacity: 0;
        transition: all 0.3s ease;
    }
    
    .toast.show {
        opacity: 1;
        transform: translateX(-50%) translateY(0);
    }
`;
document.head.appendChild(toastStyles);